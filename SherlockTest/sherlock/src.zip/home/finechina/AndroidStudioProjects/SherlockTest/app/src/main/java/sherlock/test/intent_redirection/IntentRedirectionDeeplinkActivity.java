package sherlock.test.intent_redirection;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class IntentRedirectionDeeplinkActivity extends AppCompatActivity {

    private static final String SCHEME = "sherlock";
    private static final String HOST = "intent.redirection.deeplink";
    private static final String UNSAFE_INTENT = "unsafe";
    private static final String UNSAFE_INTENT_ONE = "unsafe_one";
    private static final String SAFE_INTENT_ONE = "safe_one";
    private static final String SAFE_INTENT_TWO = "safe_two";
    private static final int REQUEST_CODE_ONE_UNSAFE = 1001;
    private static final int REQUEST_CODE_ONE_SAFE = 1002;
    private static final int REQUEST_CODE_TWO_UNSAFE = 1003;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent deeplink = getIntent();
        Uri deeplinkUri = deeplink.getData();
        if (Objects.equals(deeplink.getAction(), Intent.ACTION_VIEW) && deeplinkUri != null) {
            if (SCHEME.equals(deeplinkUri.getScheme())
                    && HOST.equals(deeplinkUri.getHost())) {
                Intent i = new Intent("sherlock.test.INTENT_REDIRECT_ACTION");
                if (getPackageManager().resolveActivity(i, 0) != null) {
                    if ("/one_unsafe".equals(deeplinkUri.getPath())) {
                        startActivityForResult(i, REQUEST_CODE_ONE_UNSAFE);
                    } else if ("/one_safe".equals(deeplinkUri.getPath())) {
                        startActivityForResult(i, REQUEST_CODE_ONE_SAFE);
                    } else if ("/two_unsafe".equals(deeplinkUri.getPath())) {
                        startActivityForResult(i, REQUEST_CODE_TWO_UNSAFE);
                    } else if ("/three_unsafe".equals(deeplinkUri.getPath())) {
                        startForResultThreeUnsafe.launch(i);
                    } else if ("/three_safe".equals(deeplinkUri.getPath())) {
                        startForResultThreeSafe.launch(i);
                    }
                }
            }
        }
    }

    @SuppressLint("UnsafeIntentLaunch")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_ONE_UNSAFE) {
                Intent bad = data.getParcelableExtra(UNSAFE_INTENT);
                startActivity(bad);
            } else if (requestCode == REQUEST_CODE_ONE_SAFE) {
                Intent good1 = data.getParcelableExtra(SAFE_INTENT_ONE);
                ComponentName origin = getCallingActivity();
                if (origin != null
                        && origin.getPackageName().equals("sherlock.test")
                        && origin.getClassName().equals("sherlock.test.intent_redirection.AllowedOriginActivity")) {
                    startActivity(good1);
                }

                Intent good2 = data.getParcelableExtra(SAFE_INTENT_TWO);
                ComponentName dest = good2.resolveActivity(getPackageManager());
                if (dest.getPackageName().equals("sherlock.test")
                        && dest.getClassName().equals("sherlock.test.intent_redirection.AllowedDestActivity")) {
                    startActivity(good2);
                }
            } else if (requestCode == REQUEST_CODE_TWO_UNSAFE) {
                startActivity(data.getParcelableExtra(UNSAFE_INTENT));
            }
        } else if (resultCode == RESULT_CANCELED) {
            if (requestCode == REQUEST_CODE_ONE_UNSAFE) {
                Intent bad = data;
                Intent bad1 = bad.getParcelableExtra(UNSAFE_INTENT);
                startActivity(bad1);
            } else if (requestCode == REQUEST_CODE_TWO_UNSAFE) {
                Intent bad = data;
                startActivity(bad.getParcelableExtra(UNSAFE_INTENT));
            }
        }
        finish();
    }

    ActivityResultLauncher<Intent> startForResultThreeUnsafe = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent bad = result.getData().getParcelableExtra(UNSAFE_INTENT);
                    startActivity(bad);
                } else if (result.getResultCode() == RESULT_CANCELED) {
                    Intent bad = result.getData();
                    Intent bad1 = bad.getParcelableExtra(UNSAFE_INTENT);
                    startActivity(bad1);

                    startActivity(bad.getParcelableExtra(UNSAFE_INTENT_ONE));
                } else if (result.getResultCode() == RESULT_FIRST_USER) {
                    startActivity(result.getData().getParcelableExtra(UNSAFE_INTENT));
                }
            }
    );

    ActivityResultLauncher<Intent> startForResultThreeSafe = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent good1 = result.getData().getParcelableExtra(SAFE_INTENT_ONE);
                    ComponentName origin = getCallingActivity();
                    assert origin != null;
                    if (origin.getPackageName().equals("sherlock.test")
                            && origin.getClassName().equals("sherlock.test.intent_redirection.AllowedOriginActivity")) {
                        startActivity(good1);
                    }

                    Intent good2 = result.getData().getParcelableExtra(SAFE_INTENT_TWO);
                    ComponentName dest = good2.resolveActivity(getPackageManager());
                    if (dest.getPackageName().equals("sherlock.test")
                            && dest.getClassName().equals("sherlock.test.intent_redirection.AllowedDestActivity")) {
                        startActivity(good2);
                    }
                }
            }
    );
}
