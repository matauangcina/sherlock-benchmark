package sherlock.test.intent_redirection;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import sherlock.test.databinding.ActivityBasicBinding;

public class IntentRedirectionBasicActivity extends AppCompatActivity {

    public static final String EXTRA_TITLE = "sherlock.test.access_to_protected_components.intent_redirection.title";
    private static final String UNSAFE_INTENT = "unsafe";
    private static final String UNSAFE_INTENT_ONE = "unsafe_one";
    private static final String UNSAFE_INTENT_TWO = "unsafe_two";
    private static final String UNSAFE_INTENT_THREE = "unsafe_three";
    private static final String SAFE_INTENT_ONE = "safe_one";
    private static final String SAFE_INTENT_TWO = "safe_two";
    private ActivityBasicBinding binding;

    public static Intent newIntent(Context packageContext, String title) {
        Intent i = new Intent(packageContext, IntentRedirectionBasicActivity.class);
        i.putExtra(EXTRA_TITLE, title);
        return i;
    }

    @SuppressLint("UnsafeIntentLaunch")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBasicBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String title = getIntent().getStringExtra(EXTRA_TITLE);
        binding.title.setText(title);

        binding.basicOneUnsafe.setOnClickListener(v1 -> {
            Intent bad = getIntent().getParcelableExtra(UNSAFE_INTENT);
            startActivity(bad);

            Intent bad1 = getIntent();
            Intent bad2 = bad1.getParcelableExtra(UNSAFE_INTENT_ONE);
            startActivity(bad2);

            startActivity(getIntent().getParcelableExtra(UNSAFE_INTENT_TWO));
            startActivity(bad1.getParcelableExtra(UNSAFE_INTENT_THREE));
        });

        binding.basicOneSafe.setOnClickListener(v1 -> {
            Intent good1 = getIntent().getParcelableExtra(SAFE_INTENT_ONE);
            ComponentName origin = getCallingActivity();
            if (origin.getPackageName().equals("sherlock.test")
                    && origin.getClassName().equals("sherlock.test.intent_redirection.AllowedOriginActivity")) {
                startActivity(good1);
            }

            Intent good2 = getIntent().getParcelableExtra(SAFE_INTENT_TWO);
            ComponentName dest = good2.resolveActivity(getPackageManager());
            if (dest.getPackageName().equals("sherlock.test")
                    && dest.getClassName().equals("sherlock.test.intent_redirection.AllowedDestActivity")) {
                startActivity(good2);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
