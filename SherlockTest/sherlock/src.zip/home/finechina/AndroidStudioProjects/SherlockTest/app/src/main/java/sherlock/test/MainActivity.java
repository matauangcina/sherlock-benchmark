package sherlock.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import sherlock.test.mutable_pending_intent.MutablePendingIntentActivity;
import sherlock.test.mutable_pending_intent.MutablePendingIntentNotifActivity;
import sherlock.test.insecure_set_result.InsecureSetResultBasicActivity;
import sherlock.test.insecure_set_result.InsecureSetResultImplicitActivity;
import sherlock.test.webview_intent_uri.WebViewIntentUriBasicActivity;
import sherlock.test.webview_intent_uri.WebViewIntentUriImplicitActivity;
import sherlock.test.databinding.ActivityMainBinding;
import sherlock.test.intent_redirection.IntentRedirectionBasicActivity;
import sherlock.test.intent_redirection.IntentRedirectionImplicitActivity;


public class MainActivity extends AppCompatActivity {

    private static final String INSECURE_SET_RESULT = "Insecure setResult";
    private static final String INTENT_REDIRECTION = "Intent Redirection";
    private static final String WEBVIEW_INTENT_URI = "WebView Intent URI";
    private static final String MUTABLE_PENDING_INTENT = "Mutable Pending Intent";
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.insecureSetResultBasic.setOnClickListener(v1 -> {
            Intent i = InsecureSetResultBasicActivity.newIntent(this, INSECURE_SET_RESULT);
            startActivity(i);
        });

        binding.insecureSetResultImplicit.setOnClickListener(v1 -> {
            Intent i = InsecureSetResultImplicitActivity.newIntent(this, INSECURE_SET_RESULT);
            startActivity(i);
        });

        binding.insecureSetResultDeeplink.setOnClickListener(v1 -> {
            Toast.makeText(this, "Access the following activity via deeplink!", Toast.LENGTH_SHORT)
                    .show();
        });

        binding.intentRedirectionBasic.setOnClickListener(v1 -> {
            Intent i = IntentRedirectionBasicActivity.newIntent(this, INTENT_REDIRECTION);
            startActivity(i);
        });

        binding.intentRedirectionImplicit.setOnClickListener(v1 -> {
            Intent i = IntentRedirectionImplicitActivity.newIntent(this, INTENT_REDIRECTION);
            startActivity(i);
        });

        binding.intentRedirectionDeeplink.setOnClickListener(v1 -> {
            Toast.makeText(this, "Access the following activity via deeplink!", Toast.LENGTH_SHORT)
                    .show();
        });

        binding.webviewIntentUriBasic.setOnClickListener(v1 -> {
            Intent i = WebViewIntentUriBasicActivity.newIntent(this, WEBVIEW_INTENT_URI);
            startActivity(i);
        });

        binding.webviewIntentUriImplicit.setOnClickListener(v1 -> {
            Intent i = WebViewIntentUriImplicitActivity.newIntent(this, WEBVIEW_INTENT_URI);
            startActivity(i);
        });

        binding.webviewIntentUriDeeplink.setOnClickListener(v1 -> {
            Toast.makeText(this, "Access the following activity via deeplink!", Toast.LENGTH_SHORT)
                    .show();
        });

        binding.mutablePendingIntentBasic.setOnClickListener(v1 -> {
            Intent i = MutablePendingIntentActivity.newIntent(this, MUTABLE_PENDING_INTENT);
            startActivity(i);
        });

        binding.mutablePendingIntentNotification.setOnClickListener(v1 -> {
            Intent i = MutablePendingIntentNotifActivity.newIntent(this, MUTABLE_PENDING_INTENT);
            startActivity(i);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}