package sherlock.test.mutable_pending_intent;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import sherlock.test.databinding.ActivityBasicBinding;

public class MutablePendingIntentActivity extends AppCompatActivity {

    private static final String EXTRA_TITLE = "sherlock.test.immutable_pending_intent.title";
    private static final String UNSAFE_ONE = "unsafe_one";
    private static final String UNSAFE_TWO = "unsafe_two";
    private static final String UNSAFE_THREE = "unsafe_three";
    private static final String UNSAFE_FOUR = "unsafe_four";
    private static final String SAFE = "safe";
    private static final int REQUEST_CODE_UNSAFE_ONE = 1001;
    private static final int REQUEST_CODE_UNSAFE_TWO = 1002;
    private static final int REQUEST_CODE_UNSAFE_THREE = 103;
    private static final int REQUEST_CODE_UNSAFE_FOUR = 104;
    private ActivityBasicBinding binding;

    public static Intent newIntent(Context packageContext, String title) {
        Intent i = new Intent(packageContext, MutablePendingIntentActivity.class);
        i.putExtra(EXTRA_TITLE, title);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBasicBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.title.setText(getIntent().getStringExtra(EXTRA_TITLE));

        binding.basicOneUnsafe.setOnClickListener(v1 -> {
            Intent badBase = new Intent();
            PendingIntent bad = PendingIntent.getActivity(this, REQUEST_CODE_UNSAFE_ONE, badBase, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            Intent badIntent = new Intent("sherlock.test.MUTABLE_PENDING_INTENT");
            badIntent.putExtra(UNSAFE_ONE, bad);
            startActivity(badIntent);

            Intent badBase1 = new Intent("sherlock.test.IMPLICIT_BASE");
            PendingIntent bad1 = PendingIntent.getActivity(this, REQUEST_CODE_UNSAFE_TWO, badBase1, PendingIntent.FLAG_MUTABLE);
            Intent badIntent1 = new Intent("sherlock.test.IMMUTABLE_PENDING_INTENT");
            badIntent1.putExtra(UNSAFE_TWO, bad1);
            startActivity(badIntent1);

            PendingIntent bad2 = PendingIntent.getActivity(this, REQUEST_CODE_UNSAFE_THREE, new Intent(), PendingIntent.FLAG_UPDATE_CURRENT);
            Intent badIntent2 = new Intent("sherlock.test.IMMUTABLE_PENDING_INTENT");
            badIntent2.putExtra(UNSAFE_THREE, bad2);
            startActivity(badIntent2);

            PendingIntent bad3 = PendingIntent.getActivity(this, REQUEST_CODE_UNSAFE_FOUR, new Intent("sherlock.test.IMPLICIT_BASE"), PendingIntent.FLAG_MUTABLE);
            Intent badIntent3 = new Intent("sherlock.test.IMMUTABLE_PENDING_INTENT");
            badIntent3.putExtra(UNSAFE_FOUR, bad3);
            startActivity(badIntent3);
        });

        binding.basicOneSafe.setOnClickListener(v1 -> {
            Intent safeBase = new Intent();
            PendingIntent good = PendingIntent.getActivity(this, 0, safeBase, PendingIntent.FLAG_IMMUTABLE);
            Intent goodIntent = new Intent();
            goodIntent.setClassName("sherlock.test",  "sherlock.test.AllowedActivity");
            goodIntent.putExtra(SAFE, good);
            startActivity(goodIntent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}