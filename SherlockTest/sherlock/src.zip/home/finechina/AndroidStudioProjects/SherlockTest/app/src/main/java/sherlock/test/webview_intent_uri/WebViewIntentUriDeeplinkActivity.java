package sherlock.test.webview_intent_uri;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Objects;

public class WebViewIntentUriDeeplinkActivity extends AppCompatActivity {

    private static final String SCHEME = "sherlock";
    private static final String HOST = "webview.intent.uri.deeplink";
    private static final String EXTRA_URL_ONE = "url_one";
    private static final String EXTRA_URL_TWO = "url_two";
    private static final String EXTRA_URL_THREE = "url_three";
    private static final String EXTRA_URL_FOUR = "url_four";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent deeplink = getIntent();
        Uri deeplinkUri = deeplink.getData();
        if (Objects.equals(deeplink.getAction(), Intent.ACTION_VIEW) && deeplinkUri != null) {
            if (SCHEME.equals(deeplinkUri.getScheme())
                    && HOST.equals(deeplinkUri.getHost())) {
                WebView webView = new WebView(this);
                if (deeplinkUri.getPath().contains("/unfiltered")) {
                    if ("one".equals(deeplinkUri.getLastPathSegment())) {
                        webView.setWebViewClient(new WebViewClient() {
                            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                                Uri uri = request.getUrl();
                                if ("intent".equals(uri.getScheme())) {
                                    try {
                                        Intent i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                                        startActivity(i);
                                        return true;
                                    } catch (URISyntaxException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                                return super.shouldOverrideUrlLoading(view, request);
                            }
                        });
                    } else if ("/two".equals(deeplinkUri.getPath())) {
                        webView.setWebViewClient(new WebViewClient() {
                            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                                Uri uri = request.getUrl();
                                if ("intent".equals(uri.getScheme())) {
                                    try {
                                        startActivity(Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME));
                                        return true;
                                    } catch (URISyntaxException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                                return super.shouldOverrideUrlLoading(view, request);
                            }
                        });
                    }
                } else if (deeplinkUri.getPath().contains("/filtered")) {
                    if ("one".equals(deeplinkUri.getLastPathSegment())) {
                        webView.setWebViewClient(new WebViewClient() {
                            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                                Uri uri = request.getUrl();
                                if ("intent".equals(uri.getScheme())) {
                                    try {
                                        Intent i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                                        i.setComponent(null);
                                        startActivity(i);
                                        return true;
                                    } catch (URISyntaxException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                                return super.shouldOverrideUrlLoading(view, request);
                            }
                        });
                    } else if ("/two".equals(deeplinkUri.getPath())) {
                        webView.setWebViewClient(new WebViewClient() {
                            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                                Uri uri = request.getUrl();
                                if ("intent".equals(uri.getScheme())) {
                                    try {
                                        Intent i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                                        i.setComponent(null);
                                        i.setSelector(null);
                                        startActivity(i);
                                        return true;
                                    } catch (URISyntaxException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                                return super.shouldOverrideUrlLoading(view, request);
                            }
                        });
                    }
                }
                if (deeplinkUri.getPath().contains("/unsafe")
                        && (deeplinkUri.getPath().indexOf("/unsafe") < deeplinkUri.getPath().indexOf("/unfiltered")
                            || deeplinkUri.getPath().indexOf("/unsafe") < deeplinkUri.getPath().indexOf("/filtered"))) {
                    webView.loadUrl(deeplinkUri.getQueryParameter(EXTRA_URL_ONE));

                    Intent bad = getIntent();
                    webView.loadUrl(bad.getData().getQueryParameter(EXTRA_URL_TWO));

                    Uri badUrl = getIntent().getData();
                    webView.loadUrl(badUrl.getQueryParameter(EXTRA_URL_THREE));

                    webView.loadUrl(getIntent().getData().getQueryParameter(EXTRA_URL_FOUR));
                } else if (deeplinkUri.getPath().contains("/safe")
                        && (deeplinkUri.getPath().indexOf("/safe") < deeplinkUri.getPath().indexOf("/unfiltered")
                        || deeplinkUri.getPath().indexOf("/safe") < deeplinkUri.getPath().indexOf("/filtered"))) {
                    String url = deeplinkUri.getQueryParameter(EXTRA_URL_ONE);
                    String [] whiteList = {"www.google.com", "www.example.com"};
                    if (Arrays.asList(whiteList).contains(url)) {
                        webView.loadUrl(url);
                    }
                }
            }
        }
    }
}
