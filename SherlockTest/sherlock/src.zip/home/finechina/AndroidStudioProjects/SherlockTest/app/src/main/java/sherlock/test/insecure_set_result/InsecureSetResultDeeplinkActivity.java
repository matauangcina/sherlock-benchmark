package sherlock.test.insecure_set_result;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

import sherlock.test.databinding.ActivityImplicitBinding;

public class InsecureSetResultDeeplinkActivity extends AppCompatActivity {

    private static final String SCHEME = "sherlock";
    private static final String HOST = "insecure.set.result.deeplink";
    private static final int REQUEST_CODE_UNSAFE_ONE = 1001;
    private static final int REQUEST_CODE_UNSAFE_TWO = 1002;
    private static final int REQUEST_CODE_SAFE = 1003;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent deeplink = getIntent();
        Uri deeplinkUri = deeplink.getData();
        if (Objects.equals(deeplink.getAction(), Intent.ACTION_VIEW) && deeplinkUri != null) {
            if (SCHEME.equals(deeplinkUri.getScheme())
                    && HOST.equals(deeplinkUri.getHost())) {
                Intent i = new Intent("sherlock.test.INSECURE_SETRESULT_ACTION");
                if (getPackageManager().resolveActivity(i, 0) != null) {
                    if ("/one_unsafe".equals(deeplinkUri.getPath())) {
                        startActivityForResult(i, REQUEST_CODE_UNSAFE_ONE);
                    } else if ("/one_safe".equals(deeplinkUri.getPath())) {
                        startActivityForResult(i, REQUEST_CODE_SAFE);
                    } else if ("/two_unsafe".equals(deeplinkUri.getPath())) {
                        startActivityForResult(i, REQUEST_CODE_UNSAFE_TWO);
                    } else if ("/three_unsafe".equals(deeplinkUri.getPath())) {
                        startForResultThreeUnsafe.launch(i);
                    } else if ("/three_safe".equals(deeplinkUri.getPath())) {
                        startForResultThreeSafe.launch(i);
                    }
                }
            }
        }
    }

    @SuppressLint("UnsafeIntentLaunch")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_UNSAFE_ONE) {
                Intent bad = data;
                setResult(RESULT_OK, bad);
            } else if (requestCode == REQUEST_CODE_SAFE) {
                data.removeFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                setResult(RESULT_OK, data);
            } else if (requestCode == REQUEST_CODE_UNSAFE_TWO) {
                setResult(RESULT_OK, data);
            }
        }
        finish();
    }

    ActivityResultLauncher<Intent> startForResultThreeUnsafe = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent bad = result.getData();
                    setResult(RESULT_OK, bad);
                    finish();
                } else if (result.getResultCode() == RESULT_CANCELED) {
                    setResult(RESULT_OK, result.getData());
                }
            }
    );

    ActivityResultLauncher<Intent> startForResultThreeSafe = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent good = result.getData();
                    good.removeFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    setResult(RESULT_OK, good);
                    finish();
                }
            }
    );
}
