package sherlock.test.intent_redirection;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import sherlock.test.databinding.ActivityImplicitBinding;

public class IntentRedirectionImplicitActivity extends AppCompatActivity {

    private static final String EXTRA_TITLE = "sherlock.test.access_to_protected_components.intent_redirection.title";
    private static final String UNSAFE_INTENT = "unsafe";
    private static final String UNSAFE_INTENT_ONE = "unsafe_one";
    private static final String SAFE_INTENT_ONE = "safe_one";
    private static final String SAFE_INTENT_TWO = "safe_two";
    private static final int REQUEST_CODE_ONE_UNSAFE = 1001;
    private static final int REQUEST_CODE_ONE_SAFE = 1002;
    private static final int REQUEST_CODE_TWO_UNSAFE = 1003;
    private ActivityImplicitBinding binding;

    public static Intent newIntent(Context packageContext, String title) {
        Intent i = new Intent(packageContext, IntentRedirectionImplicitActivity.class);
        i.putExtra(EXTRA_TITLE, title);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityImplicitBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String title = getIntent().getStringExtra(EXTRA_TITLE);
        binding.title.setText(title);

        binding.implicitOneUnsafe.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.INTENT_REDIRECT_ACTION");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startActivityForResult(i, REQUEST_CODE_ONE_UNSAFE);
            }
        });

        binding.implicitOneSafe.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.INTENT_REDIRECT_ACTION");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startActivityForResult(i, REQUEST_CODE_ONE_SAFE);
            }
        });

        binding.implicitTwoUnsafe.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.INTENT_REDIRECT_ACTION");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startActivityForResult(i, REQUEST_CODE_TWO_UNSAFE);
            }
        });

        binding.implicitTwoSafe.setVisibility(View.GONE);

        binding.implicitThreeUnsafe.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.INTENT_REDIRECT_ACTION");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startForResultThreeUnsafe.launch(i);
            }
        });

        binding.implicitThreeSafe.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.INTENT_REDIRECT_ACTION");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startForResultThreeSafe.launch(i);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }

    @SuppressLint("UnsafeIntentLaunch")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_ONE_UNSAFE) {
                Intent bad = data.getParcelableExtra(UNSAFE_INTENT);
                startActivity(bad);
            } else if (requestCode == REQUEST_CODE_ONE_SAFE) {
                Intent good1 = data.getParcelableExtra(SAFE_INTENT_ONE);
                ComponentName origin = getCallingActivity();
                if (origin != null
                        && origin.getPackageName().equals("sherlock.test")
                        && origin.getClassName().equals("sherlock.test.intent_redirection.AllowedOriginActivity")) {
                    startActivity(good1);
                }

                Intent good2 = data.getParcelableExtra(SAFE_INTENT_TWO);
                ComponentName dest = good2.resolveActivity(getPackageManager());
                if (dest.getPackageName().equals("sherlock.test")
                        && dest.getClassName().equals("sherlock.test.intent_redirection.AllowedDestActivity")) {
                    startActivity(good2);
                }
            } else if (requestCode == REQUEST_CODE_TWO_UNSAFE) {
                startActivity(data.getParcelableExtra(UNSAFE_INTENT));
            }
        } else if (resultCode == RESULT_CANCELED) {
            if (requestCode == REQUEST_CODE_ONE_UNSAFE) {
                Intent bad = data;
                Intent bad1 = bad.getParcelableExtra(UNSAFE_INTENT);
                startActivity(bad1);
            } else if (requestCode == REQUEST_CODE_TWO_UNSAFE) {
                Intent bad = data;
                startActivity(bad.getParcelableExtra(UNSAFE_INTENT));
            }
        }
        finish();
    }

    ActivityResultLauncher<Intent> startForResultThreeUnsafe = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent bad = result.getData().getParcelableExtra(UNSAFE_INTENT);
                    startActivity(bad);
                } else if (result.getResultCode() == RESULT_CANCELED) {
                    Intent bad = result.getData();
                    Intent bad1 = bad.getParcelableExtra(UNSAFE_INTENT);
                    startActivity(bad1);

                    startActivity(bad.getParcelableExtra(UNSAFE_INTENT_ONE));
                } else if (result.getResultCode() == RESULT_FIRST_USER) {
                    startActivity(result.getData().getParcelableExtra(UNSAFE_INTENT));
                }
            }
    );

    ActivityResultLauncher<Intent> startForResultThreeSafe = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent good1 = result.getData().getParcelableExtra(SAFE_INTENT_ONE);
                    ComponentName origin = getCallingActivity();
                    assert origin != null;
                    if (origin.getPackageName().equals("sherlock.test")
                            && origin.getClassName().equals("sherlock.test.intent_redirection.AllowedOriginActivity")) {
                        startActivity(good1);
                    }

                    Intent good2 = result.getData().getParcelableExtra(SAFE_INTENT_TWO);
                    ComponentName dest = good2.resolveActivity(getPackageManager());
                    if (dest.getPackageName().equals("sherlock.test")
                            && dest.getClassName().equals("sherlock.test.intent_redirection.AllowedDestActivity")) {
                        startActivity(good2);
                    }
                }
            }
    );
}
