package sherlock.test.webview_intent_uri;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import sherlock.test.databinding.ActivityWebviewBasicBinding;

public class WebViewIntentUriBasicActivity extends AppCompatActivity {

    private static final String EXTRA_TITLE = "sherlock.test.access_to_protected_components.webview.title";
    private static final String EXTRA_URL_ONE = "url_one";
    private static final String EXTRA_URL_TWO = "url_two";
    private static final String EXTRA_URL_THREE = "url_three";
    private static final String EXTRA_URL_FOUR = "url_four";
    private ActivityWebviewBasicBinding binding;

    public static Intent newIntent(Context packageContext, String title) {
        Intent i = new Intent(packageContext, WebViewIntentUriBasicActivity.class);
        i.putExtra(EXTRA_TITLE, title);
        return i;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWebviewBasicBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Map<String, String> headers = new HashMap<>();
        headers.put("ngrok-skip-browser-warning", "69420");

        binding.title.setText(getIntent().getStringExtra(EXTRA_TITLE));
        WebView webView = binding.webviewIntentUri;

        binding.basicOneUnsafeFilteredTwo.setOnClickListener(v1 -> {
            webView.setWebViewClient(new WebViewClient() {
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri uri = request.getUrl();
                    if ("intent".equals(uri.getScheme())) {
                        try {
                            Intent i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                            i.setComponent(null);
                            i.setSelector(null);
                            startActivity(i);
                            return true;
                        } catch (URISyntaxException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    return super.shouldOverrideUrlLoading(view, request);
                }
            });
            String url = getIntent().getStringExtra(EXTRA_URL_ONE);
            webView.loadUrl(url, headers);

            Intent bad = getIntent();
            String badUrl = bad.getStringExtra(EXTRA_URL_TWO);
            webView.loadUrl(badUrl, headers);

            webView.loadUrl(getIntent().getStringExtra(EXTRA_URL_THREE));

            webView.loadUrl(bad.getStringExtra(EXTRA_URL_FOUR));

            String badUrl1 = getIntent().getDataString();
            webView.loadUrl(badUrl1);
        });

        binding.basicOneSafeUnfilteredTwo.setOnClickListener(v1 -> {
            webView.setWebViewClient(new WebViewClient() {
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri uri = request.getUrl();
                    if ("intent".equals(uri.getScheme())) {
                        try {
                            startActivity(Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME));
                            return true;
                        } catch (URISyntaxException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    return super.shouldOverrideUrlLoading(view, request);
                }
            });
            String url = getIntent().getStringExtra(EXTRA_URL_ONE);
            String [] whiteList = {"www.google.com", "www.example.com"};
            if (Arrays.asList(whiteList).contains(url)) {
                webView.loadUrl(url, headers);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
