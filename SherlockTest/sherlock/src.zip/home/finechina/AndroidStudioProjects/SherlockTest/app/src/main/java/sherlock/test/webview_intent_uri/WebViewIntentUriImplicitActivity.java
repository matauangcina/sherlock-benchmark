package sherlock.test.webview_intent_uri;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import sherlock.test.databinding.ActivityWebviewImplicitBinding;

public class WebViewIntentUriImplicitActivity extends AppCompatActivity {

    private ActivityWebviewImplicitBinding binding;
    private static final String EXTRA_TITLE = "sherlock.test.access_to_protected_components.webview.title";
    private static final int REQUEST_CODE_ONE_UNSAFE = 1001;
    private static final int REQUEST_CODE_ONE_SAFE = 1002;
    private static final int REQUEST_CODE_TWO_UNSAFE = 1003;
    private static final String EXTRA_URL_ONE = "url_one";
    private static final String EXTRA_URL_TWO = "url_two";
    private final String[] mUrlWhitelist = {"www.google.com", "www.example.com"};
    private WebView mWebView;

    public static Intent newIntent(Context packageContext, String title) {
        Intent i = new Intent(packageContext, WebViewIntentUriImplicitActivity.class);
        i.putExtra(EXTRA_TITLE, title);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWebviewImplicitBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.title.setText(getIntent().getStringExtra(EXTRA_TITLE));
        mWebView = binding.webviewIntentUri;

        binding.implicitOneUnsafeFilteredOne.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.WEBVIEW_INTENT_URI");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startActivityForResult(i, REQUEST_CODE_ONE_UNSAFE);
            }
        });

        binding.implicitOneSafeUnfilteredTwo.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.WEBVIEW_INTENT_URI");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startActivityForResult(i, REQUEST_CODE_ONE_SAFE);
            }
        });

        binding.implicitTwoUnsafeFilteredTwo.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.WEBVIEW_INTENT_URI");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startActivityForResult(i, REQUEST_CODE_TWO_UNSAFE);
            }
        });

        binding.implicitThreeUnsafeFilteredOne.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.WEBVIEW_INTENT_URI");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startForResultThreeUnsafe.launch(i);
            }
        });

        binding.implicitThreeSafeUnfilteredOne.setOnClickListener(v1 -> {
            Intent i = new Intent("sherlock.test.WEBVIEW_INTENT_URI");
            if (getPackageManager().resolveActivity(i,0) != null) {
                startForResultThreeSafe.launch(i);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Map<String, String> headers = new HashMap<>();
        headers.put("ngrok-skip-browser-warning", "69420");
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_ONE_UNSAFE) {
                mWebView.setWebViewClient(new WebViewClient() {
                    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        Uri uri = request.getUrl();
                        if ("intent".equals(uri.getScheme())) {
                            try {
                                Intent i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                                i.setComponent(null);
                                startActivity(i);
                                return true;
                            } catch (URISyntaxException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        return super.shouldOverrideUrlLoading(view, request);
                    }
                });
                String bad = data.getStringExtra(EXTRA_URL_ONE);
                mWebView.loadUrl(bad, headers);
            } else if (requestCode == REQUEST_CODE_ONE_SAFE) {
                mWebView.setWebViewClient(new WebViewClient() {
                    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        Uri uri = request.getUrl();
                        if ("intent".equals(uri.getScheme())) {
                            try {
                                startActivity(Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME));
                                return true;
                            } catch (URISyntaxException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        return super.shouldOverrideUrlLoading(view, request);
                    }
                });
                String good = data.getStringExtra(EXTRA_URL_ONE);
                if (Arrays.asList(mUrlWhitelist).contains(good)) {
                    mWebView.loadUrl(good, headers);
                }
            } else if (requestCode == REQUEST_CODE_TWO_UNSAFE) {
                mWebView.setWebViewClient(new WebViewClient() {
                    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        Uri uri = request.getUrl();
                        if ("intent".equals(uri.getScheme())) {
                            try {
                                Intent i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                                i.setComponent(null);
                                i.setSelector(null);
                                startActivity(i);
                                return true;
                            } catch (URISyntaxException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        return super.shouldOverrideUrlLoading(view, request);
                    }
                });
                mWebView.loadUrl(data.getStringExtra(EXTRA_URL_ONE), headers);

                mWebView.loadUrl(data.getDataString(), headers);
            }
        } else if (resultCode == RESULT_CANCELED) {
            if (requestCode == REQUEST_CODE_ONE_UNSAFE) {
                mWebView.setWebViewClient(new WebViewClient() {
                    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        Uri uri = request.getUrl();
                        if ("intent".equals(uri.getScheme())) {
                            try {
                                Intent i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                                i.setComponent(null);
                                startActivity(i);
                                return true;
                            } catch (URISyntaxException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        return super.shouldOverrideUrlLoading(view, request);
                    }
                });
                Intent bad = data;
                String badUrl1 = bad.getStringExtra(EXTRA_URL_ONE);
                mWebView.loadUrl(badUrl1, headers);

                mWebView.loadUrl(bad.getStringExtra(EXTRA_URL_TWO), headers);

                mWebView.loadUrl(bad.getDataString(), headers);
            }
        }
    }

    ActivityResultLauncher<Intent> startForResultThreeUnsafe = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                Map<String, String> headers = new HashMap<>();
                headers.put("ngrok-skip-browser-warning", "69420");
                if (result.getResultCode() == RESULT_OK) {
                    mWebView.setWebViewClient(new WebViewClient() {
                        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                            Uri uri = request.getUrl();
                            if ("intent".equals(uri.getScheme())) {
                                try {
                                    Intent i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                                    i.setComponent(null);
                                    startActivity(i);
                                    return true;
                                } catch (URISyntaxException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                            return super.shouldOverrideUrlLoading(view, request);
                        }
                    });
                    String bad = result.getData().getDataString();
                    mWebView.loadUrl(bad, headers);

                    mWebView.loadUrl(result.getData().getStringExtra(EXTRA_URL_ONE), headers);
                } else if (result.getResultCode() == RESULT_CANCELED) {
                    Intent bad = result.getData();
                    String badUrl = bad.getStringExtra(EXTRA_URL_ONE);
                    mWebView.loadUrl(badUrl, headers);

                    mWebView.loadUrl(bad.getDataString(), headers);

                    mWebView.loadUrl(bad.getStringExtra(EXTRA_URL_TWO), headers);
                }
            }
    );

    ActivityResultLauncher<Intent> startForResultThreeSafe = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("ngrok-skip-browser-warning", "69420");
                    mWebView.setWebViewClient(new WebViewClient() {
                        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                            Uri uri = request.getUrl();
                            if ("intent".equals(uri.getScheme())) {
                                try {
                                    Intent i = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                                    startActivity(i);
                                    return true;
                                } catch (URISyntaxException e) {
                                    throw new RuntimeException(e);
                                }
                            }
                            return super.shouldOverrideUrlLoading(view, request);
                        }
                    });
                    String url = result.getData().getDataString();
                    for (String validUrl : mUrlWhitelist) {
                        if (url == validUrl) {
                            mWebView.loadUrl(url, headers);
                            break;
                        }
                    }
                }
            }
    );

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
