package sherlock.test.mutable_pending_intent;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import sherlock.test.databinding.ActivityNotificationBinding;

public class MutablePendingIntentNotifActivity extends AppCompatActivity {

    private static final String EXTRA_TITLE = "sherlock.test.mutable_pending_intent.title";
    private static final int NOTIF_CODE = 999;
    private static final int REQUEST_CODE = 1001;
    private static final String CHANNEL_ID = "id";
    private ActivityNotificationBinding binding;

    public static Intent newIntent(Context packageContext, String title) {
        Intent i = new Intent(packageContext, MutablePendingIntentNotifActivity.class);
        i.putExtra(EXTRA_TITLE, title);
        return i;
    }

    private void createNotificationChannel() {
        CharSequence name = "channel_name";
        String description = "channel_description";
        int importance = NotificationManager.IMPORTANCE_HIGH;

        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
        channel.setDescription(description);

        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(channel);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityNotificationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        createNotificationChannel();

        binding.title.setText(getIntent().getStringExtra(EXTRA_TITLE));

        binding.notificationUnsafe.setOnClickListener(v1 -> {
            Intent badBase = new Intent();
            PendingIntent pi = PendingIntent.getActivity(this,
                    REQUEST_CODE, badBase, PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            NotificationCompat.Builder notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_menu_report_image)
                    .setContentTitle("BAD!!")
                    .setContentText("Notification with mutable pending intent and implicit base intent.")
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH);

            NotificationManagerCompat nmc = NotificationManagerCompat.from(this);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                nmc.notify(NOTIF_CODE, notification.build());
            }
        });

        binding.notificationSafe.setOnClickListener(v1 -> {
            Intent goodBase = new Intent();
            goodBase.setClassName("sherlock.test", "sherlock.test.AllowedActivity");
            PendingIntent pi = PendingIntent.getActivity(this,
                    REQUEST_CODE, goodBase, PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_menu_report_image)
                    .setContentTitle("GOOD..")
                    .setContentText("Notification with immutable pending intent and explicit base intent.")
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH);

            NotificationManagerCompat nmc = NotificationManagerCompat.from(this);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                nmc.notify(NOTIF_CODE, notification.build());
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
